import streamlit as st
import pandas as pd
import time
import os

st.set_page_config(page_title="Cyber AI Monitor", layout="wide")

# ---------- STYLING ----------
st.markdown("""
<style>
.stApp {
    background: radial-gradient(circle at top, #0f172a, #020617);
    color: white;
}

/* Layout spacing */
.block-container {
    padding-top: 2rem;
    padding-bottom: 2rem;
}

/* Glass Card */
.card {
    padding: 20px;
    border-radius: 16px;
    background: rgba(255, 255, 255, 0.05);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid rgba(255,255,255,0.1);
    box-shadow: 0 8px 32px rgba(0,0,0,0.5);
    margin-bottom: 20px;
    transition: all 0.3s ease;
}

/* Hover effect */
.card:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 40px rgba(0,0,0,0.7);
}

/* Metrics text */
.metric-title {
    font-size: 14px;
    color: #cbd5f5;
}

.metric-value {
    font-size: 36px;
    font-weight: bold;
}

/* Alert styling */
.card b {
    font-size: 16px;
}

/* Sidebar dropdown cursor */
div[data-baseweb="select"] * {
    cursor: pointer !important;
}

/* Smooth scroll feel */
html {
    scroll-behavior: smooth;
}
</style>
""", unsafe_allow_html=True)

# ---------- HEADER ----------
st.markdown("<h1 style='margin-bottom:0;'>🚨 Cyber AI Monitor</h1>", unsafe_allow_html=True)
st.markdown("<p style='color:#aaa;margin-top:0;'>Real-time Network Threat Detection Dashboard</p>", unsafe_allow_html=True)
st.divider()

# ---------- SIDEBAR ----------
with st.sidebar:
    st.header("⚙️ Controls")
    filter_option = st.selectbox("Filter Traffic", ["ALL", "ATTACK", "NORMAL"])
    auto_refresh = st.toggle("Auto Refresh", True)

# ---------- LOAD DATA ----------
log_file = "logs/detections.csv"

if os.path.exists(log_file):
    df = pd.read_csv(log_file)

    if not df.empty:
        df = df.sort_values(by="timestamp", ascending=False)

        if filter_option != "ALL":
            df = df[df["result"] == filter_option]

        # Handle empty dataframe after filtering
        if df.empty:
            st.warning("No data available for selected filter")
            st.stop()

        # ---------- ALERT ----------
        latest = df.iloc[0]["result"]

        if latest == "ATTACK":
            st.markdown("<div class='card' style='border-left:5px solid #ff4b4b;'>⚠️ <b>SYSTEM UNDER ATTACK</b></div>", unsafe_allow_html=True)
        else:
            st.markdown("<div class='card' style='border-left:5px solid #2ecc71;'>✅ <b>System Normal</b></div>", unsafe_allow_html=True)

        # ---------- METRICS ----------
        attack_count = (df["result"] == "ATTACK").sum()
        normal_count = (df["result"] == "NORMAL").sum()

        col1, col2 = st.columns(2, gap="large")

        with col1:
            st.markdown(f"""
            <div class='card'>
                <div class='metric-title'>🔴 Total Attacks</div>
                <div class='metric-value'>{attack_count}</div>
            </div>
            """, unsafe_allow_html=True)

        with col2:
            st.markdown(f"""
            <div class='card'>
                <div class='metric-title'>🟢 Normal Traffic</div>
                <div class='metric-value'>{normal_count}</div>
            </div>
            """, unsafe_allow_html=True)

        # ---------- GRAPH ----------
        st.markdown("### 📊 Attack Trend")

        df_graph = df.copy()
        df_graph["timestamp"] = pd.to_datetime(df_graph["timestamp"], errors="coerce")
        df_graph = df_graph.dropna()
        df_graph["attack_flag"] = (df_graph["result"] == "ATTACK").astype(int)
        df_graph = df_graph.set_index("timestamp").sort_index()

        st.line_chart(df_graph["attack_flag"])

        # ---------- TABLE ----------
        st.markdown("### 📄 Live Traffic Logs")

        def highlight(row):
            if row["result"] == "ATTACK":
                return ['background-color: rgba(255,75,75,0.2)'] * len(row)
            else:
                return ['background-color: rgba(46,204,113,0.2)'] * len(row)

        st.dataframe(df.style.apply(highlight, axis=1), use_container_width=True)

    else:
        st.info("Waiting for data...")
else:
    st.warning("Log file not found")

# ---------- REFRESH ----------
if auto_refresh:
    time.sleep(2)
    st.rerun()